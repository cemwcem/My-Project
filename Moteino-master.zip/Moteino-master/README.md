Moteino
=======

Moteino Eagle project and library.
Moteino is now shipping with DualOptiboot: https://github.com/LowPowerLab/DualOptiboot
DualOptiboot allows for wireless programming using an external FLASH chip soldered to Moteino on the provided footprint.

#License
CC-BY-SA 4.0
https://creativecommons.org/licenses/by-sa/4.0/
You are free to share and adapt. But you need to give attribution and use the same license to redistribute.
